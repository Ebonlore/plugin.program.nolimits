import os,shutil,time
import xbmc, xbmcaddon
from io import BytesIO
from urllib.request import urlopen
from zipfile import ZipFile

addon_id = 'plugin.program.nolimits'
selfAddon = xbmcaddon.Addon(id=addon_id)
limit = selfAddon.getSetting('limit')
update = selfAddon.getSetting('update')

def tmdbupdate():
	dest = xbmc.translatePath('special://home/addons/')
	tmdbdest = xbmc.translatePath('special://home/addons/plugin.video.themoviedb.helper')
	extractdest = xbmc.translatePath('special://home/addons/plugin.video.themoviedb.helper-matrix')
	if update == 'true':
		zipurl = 'https://github.com/jurialmunkey/plugin.video.themoviedb.helper/archive/refs/heads/matrix.zip'
		with urlopen(zipurl) as zipresp:
			with ZipFile(BytesIO(zipresp.read())) as zfile:
				zfile.extractall(dest)
		shutil.rmtree(tmdbdest)
		os.rename(extractdest,tmdbdest)

def freplace():
	fedit = xbmc.translatePath('special://home/addons/plugin.video.themoviedb.helper/resources/lib/api/trakt/api.py')
	f = open(fedit,'r')
	filedata = f.read()
	f.close()
	textlimit = "limit: int = "
	newlimit = textlimit + limit
	newdata = filedata.replace("limit: int = 20",newlimit)
	f = open(fedit,'w')
	f.write(newdata)
	f.close()

time.sleep(300)
tmdbupdate()
freplace()
xbmc.executebuiltin('UpdateAddonRepos')